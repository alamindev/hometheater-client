import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b761c0c4 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _69d40b20 = () => interopDefault(import('..\\pages\\blogs\\index.vue' /* webpackChunkName: "pages/blogs/index" */))
const _1e28e5d0 = () => interopDefault(import('..\\pages\\booking\\index.vue' /* webpackChunkName: "pages/booking/index" */))
const _001d3ac2 = () => interopDefault(import('..\\pages\\cart.vue' /* webpackChunkName: "pages/cart" */))
const _22b83fac = () => interopDefault(import('..\\pages\\contact-us.vue' /* webpackChunkName: "pages/contact-us" */))
const _5e998f02 = () => interopDefault(import('..\\pages\\gallery\\index.vue' /* webpackChunkName: "pages/gallery/index" */))
const _24774546 = () => interopDefault(import('..\\pages\\services.vue' /* webpackChunkName: "pages/services" */))
const _0c7de126 = () => interopDefault(import('..\\pages\\shop\\index.vue' /* webpackChunkName: "pages/shop/index" */))
const _0194fc81 = () => interopDefault(import('..\\pages\\auth\\change-password.vue' /* webpackChunkName: "pages/auth/change-password" */))
const _05b61fee = () => interopDefault(import('..\\pages\\auth\\forgot-password.vue' /* webpackChunkName: "pages/auth/forgot-password" */))
const _55406c92 = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _db28e9ec = () => interopDefault(import('..\\pages\\auth\\register.vue' /* webpackChunkName: "pages/auth/register" */))
const _371b96e4 = () => interopDefault(import('..\\pages\\auth\\social-callback.vue' /* webpackChunkName: "pages/auth/social-callback" */))
const _b425a36e = () => interopDefault(import('..\\pages\\search\\blog.vue' /* webpackChunkName: "pages/search/blog" */))
const _23d4db5e = () => interopDefault(import('..\\pages\\search\\service.vue' /* webpackChunkName: "pages/search/service" */))
const _0878a872 = () => interopDefault(import('..\\pages\\users\\booking\\index.vue' /* webpackChunkName: "pages/users/booking/index" */))
const _66df1b0b = () => interopDefault(import('..\\pages\\users\\dashboard.vue' /* webpackChunkName: "pages/users/dashboard" */))
const _003a4a1c = () => interopDefault(import('..\\pages\\users\\product\\index.vue' /* webpackChunkName: "pages/users/product/index" */))
const _690b68f1 = () => interopDefault(import('..\\pages\\users\\review\\index.vue' /* webpackChunkName: "pages/users/review/index" */))
const _cfe07508 = () => interopDefault(import('..\\pages\\users\\settings.vue' /* webpackChunkName: "pages/users/settings" */))
const _77f20b3a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _ac177450 = () => interopDefault(import('..\\pages\\users\\booking\\_id\\details.vue' /* webpackChunkName: "pages/users/booking/_id/details" */))
const _dbb82b38 = () => interopDefault(import('..\\pages\\users\\booking\\_id\\edit.vue' /* webpackChunkName: "pages/users/booking/_id/edit" */))
const _19b5179c = () => interopDefault(import('..\\pages\\users\\booking\\_id\\review.vue' /* webpackChunkName: "pages/users/booking/_id/review" */))
const _3fd350ee = () => interopDefault(import('..\\pages\\users\\product\\_id\\details.vue' /* webpackChunkName: "pages/users/product/_id/details" */))
const _424dae5c = () => interopDefault(import('..\\pages\\users\\product\\_id\\review.vue' /* webpackChunkName: "pages/users/product/_id/review" */))
const _4b7ec879 = () => interopDefault(import('..\\pages\\users\\review\\_id\\details.vue' /* webpackChunkName: "pages/users/review/_id/details" */))
const _1b57593a = () => interopDefault(import('..\\pages\\users\\review\\_id\\edit.vue' /* webpackChunkName: "pages/users/review/_id/edit" */))
const _681d69d8 = () => interopDefault(import('..\\pages\\blogs\\_slug.vue' /* webpackChunkName: "pages/blogs/_slug" */))
const _6bc37eb2 = () => interopDefault(import('..\\pages\\booking\\_slug\\index.vue' /* webpackChunkName: "pages/booking/_slug/index" */))
const _6206d192 = () => interopDefault(import('..\\pages\\gallery\\_slug.vue' /* webpackChunkName: "pages/gallery/_slug" */))
const _16a54628 = () => interopDefault(import('..\\pages\\page\\_slug.vue' /* webpackChunkName: "pages/page/_slug" */))
const _e048ba86 = () => interopDefault(import('..\\pages\\shop\\_slug\\index.vue' /* webpackChunkName: "pages/shop/_slug/index" */))
const _1381c888 = () => interopDefault(import('..\\pages\\users\\_id\\profile.vue' /* webpackChunkName: "pages/users/_id/profile" */))
const _348c720c = () => interopDefault(import('..\\pages\\auth\\login' /* webpackChunkName: "" */))
const _67323d1c = () => interopDefault(import('..\\pages\\auth\\register' /* webpackChunkName: "" */))
const _6030ef54 = () => interopDefault(import('..\\pages\\auth\\forgot-password' /* webpackChunkName: "" */))
const _060cb32e = () => interopDefault(import('..\\pages\\auth\\change-password' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _b761c0c4,
    meta: {},
    alias: ["/amp/about"],
    name: "about"
  }, {
    path: "/blogs",
    component: _69d40b20,
    meta: {},
    alias: ["/amp/blogs"],
    name: "blogs"
  }, {
    path: "/booking",
    component: _1e28e5d0,
    meta: {},
    alias: ["/amp/booking"],
    name: "booking"
  }, {
    path: "/cart",
    component: _001d3ac2,
    meta: {},
    alias: ["/amp/cart"],
    name: "cart"
  }, {
    path: "/contact-us",
    component: _22b83fac,
    meta: {},
    alias: ["/amp/contact-us"],
    name: "contact-us"
  }, {
    path: "/gallery",
    component: _5e998f02,
    meta: {},
    alias: ["/amp/gallery"],
    name: "gallery"
  }, {
    path: "/services",
    component: _24774546,
    meta: {},
    alias: ["/amp/services"],
    name: "services"
  }, {
    path: "/shop",
    component: _0c7de126,
    meta: {},
    alias: ["/amp/shop"],
    name: "shop"
  }, {
    path: "/auth/change-password",
    component: _0194fc81,
    meta: {},
    alias: ["/amp/auth/change-password"],
    name: "auth-change-password"
  }, {
    path: "/auth/forgot-password",
    component: _05b61fee,
    meta: {},
    alias: ["/amp/auth/forgot-password"],
    name: "auth-forgot-password"
  }, {
    path: "/auth/login",
    component: _55406c92,
    meta: {},
    alias: ["/amp/auth/login"],
    name: "auth-login"
  }, {
    path: "/auth/register",
    component: _db28e9ec,
    meta: {},
    alias: ["/amp/auth/register"],
    name: "auth-register"
  }, {
    path: "/auth/social-callback",
    component: _371b96e4,
    meta: {},
    alias: ["/amp/auth/social-callback"],
    name: "auth-social-callback"
  }, {
    path: "/search/blog",
    component: _b425a36e,
    meta: {},
    alias: ["/amp/search/blog"],
    name: "search-blog"
  }, {
    path: "/search/service",
    component: _23d4db5e,
    meta: {},
    alias: ["/amp/search/service"],
    name: "search-service"
  }, {
    path: "/users/booking",
    component: _0878a872,
    meta: {},
    alias: ["/amp/users/booking"],
    name: "users-booking"
  }, {
    path: "/users/dashboard",
    component: _66df1b0b,
    meta: {},
    alias: ["/amp/users/dashboard"],
    name: "users-dashboard"
  }, {
    path: "/users/product",
    component: _003a4a1c,
    meta: {},
    alias: ["/amp/users/product"],
    name: "users-product"
  }, {
    path: "/users/review",
    component: _690b68f1,
    meta: {},
    alias: ["/amp/users/review"],
    name: "users-review"
  }, {
    path: "/users/settings",
    component: _cfe07508,
    meta: {},
    alias: ["/amp/users/settings"],
    name: "users-settings"
  }, {
    path: "/",
    component: _77f20b3a,
    meta: {},
    alias: ["/amp/"],
    name: "index"
  }, {
    path: "/users/booking/:id/details",
    component: _ac177450,
    meta: {},
    alias: ["/amp/users/booking/:id/details"],
    name: "users-booking-id-details"
  }, {
    path: "/users/booking/:id/edit",
    component: _dbb82b38,
    meta: {},
    alias: ["/amp/users/booking/:id/edit"],
    name: "users-booking-id-edit"
  }, {
    path: "/users/booking/:id/review",
    component: _19b5179c,
    meta: {},
    alias: ["/amp/users/booking/:id/review"],
    name: "users-booking-id-review"
  }, {
    path: "/users/product/:id/details",
    component: _3fd350ee,
    meta: {},
    alias: ["/amp/users/product/:id/details"],
    name: "users-product-id-details"
  }, {
    path: "/users/product/:id/review",
    component: _424dae5c,
    meta: {},
    alias: ["/amp/users/product/:id/review"],
    name: "users-product-id-review"
  }, {
    path: "/users/review/:id/details",
    component: _4b7ec879,
    meta: {},
    alias: ["/amp/users/review/:id/details"],
    name: "users-review-id-details"
  }, {
    path: "/users/review/:id/edit",
    component: _1b57593a,
    meta: {},
    alias: ["/amp/users/review/:id/edit"],
    name: "users-review-id-edit"
  }, {
    path: "/blogs/:slug",
    component: _681d69d8,
    meta: {},
    alias: ["/amp/blogs/:slug"],
    name: "blogs-slug"
  }, {
    path: "/booking/:slug",
    component: _6bc37eb2,
    meta: {},
    alias: ["/amp/booking/:slug"],
    name: "booking-slug"
  }, {
    path: "/gallery/:slug",
    component: _6206d192,
    meta: {},
    alias: ["/amp/gallery/:slug"],
    name: "gallery-slug"
  }, {
    path: "/page/:slug?",
    component: _16a54628,
    meta: {},
    alias: ["/amp/page/:slug?"],
    name: "page-slug"
  }, {
    path: "/shop/:slug",
    component: _e048ba86,
    meta: {},
    alias: ["/amp/shop/:slug"],
    name: "shop-slug"
  }, {
    path: "/users/:id?/profile",
    component: _1381c888,
    meta: {},
    alias: ["/amp/users/:id?/profile"],
    name: "users-id-profile"
  }, {
    path: "/login",
    components: {
      default: _348c720c
    },
    meta: {},
    alias: ["/amp/login"]
  }, {
    path: "/register",
    components: {
      default: _67323d1c
    },
    meta: {},
    alias: ["/amp/register"]
  }, {
    path: "/forgot-password",
    components: {
      default: _6030ef54
    },
    meta: {},
    alias: ["/amp/forgot-password"]
  }, {
    path: "/change-password",
    components: {
      default: _060cb32e
    },
    meta: {},
    alias: ["/amp/change-password"]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
