export const Circles = () => import('../..\\components\\Circles.vue' /* webpackChunkName: "components/circles" */).then(c => wrapFunctional(c.default || c))
export const Clock = () => import('../..\\components\\Clock.vue' /* webpackChunkName: "components/clock" */).then(c => wrapFunctional(c.default || c))
export const Divider = () => import('../..\\components\\Divider.vue' /* webpackChunkName: "components/divider" */).then(c => wrapFunctional(c.default || c))
export const Dot = () => import('../..\\components\\Dot.vue' /* webpackChunkName: "components/dot" */).then(c => wrapFunctional(c.default || c))
export const DotBlog = () => import('../..\\components\\DotBlog.vue' /* webpackChunkName: "components/dot-blog" */).then(c => wrapFunctional(c.default || c))
export const Heading = () => import('../..\\components\\Heading.vue' /* webpackChunkName: "components/heading" */).then(c => wrapFunctional(c.default || c))
export const ImgPopup = () => import('../..\\components\\ImgPopup.vue' /* webpackChunkName: "components/img-popup" */).then(c => wrapFunctional(c.default || c))
export const Paginator = () => import('../..\\components\\Paginator.vue' /* webpackChunkName: "components/paginator" */).then(c => wrapFunctional(c.default || c))
export const Search = () => import('../..\\components\\Search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c))
export const SocialLogin = () => import('../..\\components\\SocialLogin.vue' /* webpackChunkName: "components/social-login" */).then(c => wrapFunctional(c.default || c))
export const StatusBox = () => import('../..\\components\\StatusBox.vue' /* webpackChunkName: "components/status-box" */).then(c => wrapFunctional(c.default || c))
export const Suggestion = () => import('../..\\components\\Suggestion.vue' /* webpackChunkName: "components/suggestion" */).then(c => wrapFunctional(c.default || c))
export const SuggestionCart = () => import('../..\\components\\SuggestionCart.vue' /* webpackChunkName: "components/suggestion-cart" */).then(c => wrapFunctional(c.default || c))
export const VueSelectBox = () => import('../..\\components\\VueSelectBox.vue' /* webpackChunkName: "components/vue-select-box" */).then(c => wrapFunctional(c.default || c))
export const AuthImg = () => import('../..\\components\\auth\\authImg.vue' /* webpackChunkName: "components/auth-img" */).then(c => wrapFunctional(c.default || c))
export const Blog = () => import('../..\\components\\Blog\\Blog.vue' /* webpackChunkName: "components/blog" */).then(c => wrapFunctional(c.default || c))
export const BlogRecentLoading = () => import('../..\\components\\Blog\\RecentLoading.vue' /* webpackChunkName: "components/blog-recent-loading" */).then(c => wrapFunctional(c.default || c))
export const BlogRecentPost = () => import('../..\\components\\Blog\\RecentPost.vue' /* webpackChunkName: "components/blog-recent-post" */).then(c => wrapFunctional(c.default || c))
export const BlogShareBlogLike = () => import('../..\\components\\Blog\\ShareBlogLike.vue' /* webpackChunkName: "components/blog-share-blog-like" */).then(c => wrapFunctional(c.default || c))
export const BlogSubscribeBlog = () => import('../..\\components\\Blog\\SubscribeBlog.vue' /* webpackChunkName: "components/blog-subscribe-blog" */).then(c => wrapFunctional(c.default || c))
export const CartAddress = () => import('../..\\components\\Cart\\Address.vue' /* webpackChunkName: "components/cart-address" */).then(c => wrapFunctional(c.default || c))
export const CartBreadcrum = () => import('../..\\components\\Cart\\Breadcrum.vue' /* webpackChunkName: "components/cart-breadcrum" */).then(c => wrapFunctional(c.default || c))
export const CartBreadcrumMobile = () => import('../..\\components\\Cart\\BreadcrumMobile.vue' /* webpackChunkName: "components/cart-breadcrum-mobile" */).then(c => wrapFunctional(c.default || c))
export const CartCalendar = () => import('../..\\components\\Cart\\Calendar.vue' /* webpackChunkName: "components/cart-calendar" */).then(c => wrapFunctional(c.default || c))
export const CartItems = () => import('../..\\components\\Cart\\CartItems.vue' /* webpackChunkName: "components/cart-items" */).then(c => wrapFunctional(c.default || c))
export const CartEditCalendar = () => import('../..\\components\\Cart\\EditCalendar.vue' /* webpackChunkName: "components/cart-edit-calendar" */).then(c => wrapFunctional(c.default || c))
export const CartEditImage = () => import('../..\\components\\Cart\\EditImage.vue' /* webpackChunkName: "components/cart-edit-image" */).then(c => wrapFunctional(c.default || c))
export const CartFinalStep = () => import('../..\\components\\Cart\\FinalStep.vue' /* webpackChunkName: "components/cart-final-step" */).then(c => wrapFunctional(c.default || c))
export const CartFinishedCheckout = () => import('../..\\components\\Cart\\FinishedCheckout.vue' /* webpackChunkName: "components/cart-finished-checkout" */).then(c => wrapFunctional(c.default || c))
export const CartLogin = () => import('../..\\components\\Cart\\Login.vue' /* webpackChunkName: "components/cart-login" */).then(c => wrapFunctional(c.default || c))
export const CartMobileFooter = () => import('../..\\components\\Cart\\MobileFooter.vue' /* webpackChunkName: "components/cart-mobile-footer" */).then(c => wrapFunctional(c.default || c))
export const CartOrderMobileSummary = () => import('../..\\components\\Cart\\OrderMobileSummary.vue' /* webpackChunkName: "components/cart-order-mobile-summary" */).then(c => wrapFunctional(c.default || c))
export const CartOrderSummery = () => import('../..\\components\\Cart\\OrderSummery.vue' /* webpackChunkName: "components/cart-order-summery" */).then(c => wrapFunctional(c.default || c))
export const CartPaymentForm = () => import('../..\\components\\Cart\\PaymentForm.vue' /* webpackChunkName: "components/cart-payment-form" */).then(c => wrapFunctional(c.default || c))
export const CartQuestions = () => import('../..\\components\\Cart\\Questions.vue' /* webpackChunkName: "components/cart-questions" */).then(c => wrapFunctional(c.default || c))
export const CartRegister = () => import('../..\\components\\Cart\\Register.vue' /* webpackChunkName: "components/cart-register" */).then(c => wrapFunctional(c.default || c))
export const CartRequiredFields = () => import('../..\\components\\Cart\\RequiredFields.vue' /* webpackChunkName: "components/cart-required-fields" */).then(c => wrapFunctional(c.default || c))
export const CartUploadImage = () => import('../..\\components\\Cart\\UploadImage.vue' /* webpackChunkName: "components/cart-upload-image" */).then(c => wrapFunctional(c.default || c))
export const CartZipCode = () => import('../..\\components\\Cart\\ZipCode.vue' /* webpackChunkName: "components/cart-zip-code" */).then(c => wrapFunctional(c.default || c))
export const Booking = () => import('../..\\components\\Booking\\Booking.vue' /* webpackChunkName: "components/booking" */).then(c => wrapFunctional(c.default || c))
export const BookingService = () => import('../..\\components\\Booking\\Service.vue' /* webpackChunkName: "components/booking-service" */).then(c => wrapFunctional(c.default || c))
export const BookingSuggestionCart = () => import('../..\\components\\Booking\\SuggestionCart.vue' /* webpackChunkName: "components/booking-suggestion-cart" */).then(c => wrapFunctional(c.default || c))
export const DefaultCheckZip = () => import('../..\\components\\Default\\CheckZip.vue' /* webpackChunkName: "components/default-check-zip" */).then(c => wrapFunctional(c.default || c))
export const DefaultFooter = () => import('../..\\components\\Default\\Footer.vue' /* webpackChunkName: "components/default-footer" */).then(c => wrapFunctional(c.default || c))
export const DefaultHeader = () => import('../..\\components\\Default\\Header.vue' /* webpackChunkName: "components/default-header" */).then(c => wrapFunctional(c.default || c))
export const GalleryComments = () => import('../..\\components\\Gallery\\Comments.vue' /* webpackChunkName: "components/gallery-comments" */).then(c => wrapFunctional(c.default || c))
export const GalleryCommentSubmit = () => import('../..\\components\\Gallery\\CommentSubmit.vue' /* webpackChunkName: "components/gallery-comment-submit" */).then(c => wrapFunctional(c.default || c))
export const GalleryCountable = () => import('../..\\components\\Gallery\\Countable.vue' /* webpackChunkName: "components/gallery-countable" */).then(c => wrapFunctional(c.default || c))
export const GallerySidebar = () => import('../..\\components\\Gallery\\GallerySidebar.vue' /* webpackChunkName: "components/gallery-sidebar" */).then(c => wrapFunctional(c.default || c))
export const GallerySortby = () => import('../..\\components\\Gallery\\Sortby.vue' /* webpackChunkName: "components/gallery-sortby" */).then(c => wrapFunctional(c.default || c))
export const GallerySuggestGallery = () => import('../..\\components\\Gallery\\SuggestGallery.vue' /* webpackChunkName: "components/gallery-suggest-gallery" */).then(c => wrapFunctional(c.default || c))
export const HeaderLogo = () => import('../..\\components\\Header\\Logo.vue' /* webpackChunkName: "components/header-logo" */).then(c => wrapFunctional(c.default || c))
export const HeaderMenu = () => import('../..\\components\\Header\\Menu.vue' /* webpackChunkName: "components/header-menu" */).then(c => wrapFunctional(c.default || c))
export const HomeBanner = () => import('../..\\components\\Home\\Banner.vue' /* webpackChunkName: "components/home-banner" */).then(c => wrapFunctional(c.default || c))
export const HomeService = () => import('../..\\components\\Home\\Service.vue' /* webpackChunkName: "components/home-service" */).then(c => wrapFunctional(c.default || c))
export const HomeWhy = () => import('../..\\components\\Home\\Why.vue' /* webpackChunkName: "components/home-why" */).then(c => wrapFunctional(c.default || c))
export const LoaderLoadingWhite = () => import('../..\\components\\Loader\\Loading-white.vue' /* webpackChunkName: "components/loader-loading-white" */).then(c => wrapFunctional(c.default || c))
export const Product = () => import('../..\\components\\Product\\Product.vue' /* webpackChunkName: "components/product" */).then(c => wrapFunctional(c.default || c))
export const ProductService = () => import('../..\\components\\Product\\Service.vue' /* webpackChunkName: "components/product-service" */).then(c => wrapFunctional(c.default || c))
export const ProductSuggestionCart = () => import('../..\\components\\Product\\SuggestionCart.vue' /* webpackChunkName: "components/product-suggestion-cart" */).then(c => wrapFunctional(c.default || c))
export const ProfileActivity = () => import('../..\\components\\Profile\\ProfileActivity.vue' /* webpackChunkName: "components/profile-activity" */).then(c => wrapFunctional(c.default || c))
export const ProfileInfo = () => import('../..\\components\\Profile\\ProfileInfo.vue' /* webpackChunkName: "components/profile-info" */).then(c => wrapFunctional(c.default || c))
export const ReviewAddImage = () => import('../..\\components\\Review\\AddImage.vue' /* webpackChunkName: "components/review-add-image" */).then(c => wrapFunctional(c.default || c))
export const ReviewEditImage = () => import('../..\\components\\Review\\EditImage.vue' /* webpackChunkName: "components/review-edit-image" */).then(c => wrapFunctional(c.default || c))
export const ReviewInputFile = () => import('../..\\components\\Review\\InputFile.vue' /* webpackChunkName: "components/review-input-file" */).then(c => wrapFunctional(c.default || c))
export const ReviewPaginator = () => import('../..\\components\\Review\\ReviewPaginator.vue' /* webpackChunkName: "components/review-paginator" */).then(c => wrapFunctional(c.default || c))
export const ReviewShowImg = () => import('../..\\components\\Review\\ShowImg.vue' /* webpackChunkName: "components/review-show-img" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
